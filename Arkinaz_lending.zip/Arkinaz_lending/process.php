<?php include 'database.php'; ?>

<?php

// create a variable
$first_name=$_POST['first_name'];
$last_name=$_POST['last_name'];
$room=$_POST['room'];
$duration=$_POST['duration'];
$email=$_POST['email'];

//Execute the query


mysqli_query($connect,"INSERT INTO empoyees1 (first_name,last_name,room,duration,email)
		        VALUES ('$first_name','$last_name','$room','$duration','$email')");
				
	if(mysqli_affected_rows($connect) > 0){
		echo"<h1> Thank You!!!</h1>";
		echo "<h1>$first_name</h1>";
	echo "<h1>Бөлме сәтті броньдалды</p>";
        echo"<br><br><h3>Басты бетке өту үшін</h3>";
	echo '<a href="index.html"><h3>Осыны басыныз</h3></a>';
} else {
	echo "Сіздің бөлмеңіз броньдалмады <br />";
	echo mysqli_error ($connect);
}