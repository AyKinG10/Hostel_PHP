<!DOCTYPE html>
<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
   
<title>Астана қонақ үйі</title>
<style>
label{
  display:inline-block;
  width:100px;
  margin-bottom:10px;}
body  {

  background-color: antiquewhite;
}
fieldset {
  font-size:12px;
  padding:10px;
  width:250px;
  line-height:1.8;}

label:hover {
  cursor:hand;
}
</style>
</head>
<body>
 
<form class="form-group"  align='center' method="post" action="process.php" >
<fieldset>
<legend>Орынды броньдау:</legend>
<label>Есіміңіз</label>
<input type="text" name="first_name" />
<br />
<label>тегіңіз:</label>
<input type="text" name="last_name" />
<br />
<label>Бөлме</label><br />
  <select name="room">
    <option value="deluxe">Сәнді</option>
    <option value="semi_deluxe">Жартылай сәнді</option>
    <option value="regular">Стандарт</option>
    <option value="luxury">Люкс</option>
  </select>
<br><br>
<label>Қанша уақытка</label>
<input type="number" name="duration" />
<br />
<label>Email</label>
<input type="text" name="email" />
 
<br />
<input type="submit" value="Book Room">
 </fieldset>
</form>
 
 
 
</body>
</html>