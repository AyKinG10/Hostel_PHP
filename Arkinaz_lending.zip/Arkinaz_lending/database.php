<?php
$connect=mysqli_connect('localhost','root','','arkinaz');
if(mysqli_connect_errno())
{
		echo 'Failed to connect';
}

?>